# Amy Lewis - Book object for Book Manager Pro

from dataclasses import dataclass

@dataclass
class Book:
    bookID: int = 0
    bookName: str = ""
    genre: str = ""
    numOfPages: int = 0
