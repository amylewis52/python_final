# Amy Lewis - User Interface for Book Manager Pro - a program that managing a collection of books.
# The program connects to an SQLite database to store information about each book.
# Users can interact with the program through this simple command-line interface.

import db
from objects import Book

# Retrieves/displays list of books
def display_books():
    books = db.get_books()
    if not books:
        print("There are currently no books in the database.")
    else:
        # Formatting to look like a table in the console
        print(f"{'ID':<3}{'Book Name':<25}{'Genre':<15}{'Num of Pages':<15}")
        print("=" * 75)
        for book in books:
            # Formatting so books with long titles move onto a new line
            book_name_lines = [book.bookName[i:i + 25] for i in range(0, len(book.bookName), 25)]
            for line_num, line in enumerate(book_name_lines, start=1):
                if line_num == 1:
                    print(f"{book.bookID:<3}{line:25}  {book.genre:<15}{book.numOfPages:<15}")
                else:
                    print(f"{'':<3}{line:25}{'':<15}{'':<15}")

# Prompt for book details in order to add new book to db
def add_book():
    book_name = input("Enter book name: ")
    genre = input("Enter genre: ")
    num_of_pages = int(input("Enter number of pages: "))

    # Creates book object to add to database
    new_book = Book(bookName=book_name, genre=genre, numOfPages=num_of_pages)
    db.add_book(new_book)
    print(f"{new_book.bookName} was added.\n")

# Prompt for book ID to edit
def edit_book():
    display_books()
    book_id = int(input("Enter the ID of the book to edit: "))
    existing_book = db.get_book(book_id)

    # Checks that the book exists, allows user to keep existing data
    if existing_book:
        print(f"Editing Book: {existing_book.bookName}")
        book_name = input("Enter new book name (press Enter to keep current): ")
        genre = input("Enter new genre (press Enter to keep current): ")
        num_of_pages = input("Enter new number of pages (press Enter to keep current): ")

        if book_name:
            existing_book.bookName = book_name
        if genre:
            existing_book.genre = genre
        if num_of_pages:
            existing_book.numOfPages = int(num_of_pages)
        
        db.update_book(existing_book)
        print(f"{existing_book.bookName} was updated.\n")
    else:
        print("Book not found.")

# Deletes a book from the database
def delete_book():
    display_books()
    book_id = int(input("Enter the ID of the book to delete: "))
    existing_book = db.get_book(book_id)

    # Checks that the book exists
    if existing_book:
        confirm_delete = input(f"Are you sure you want to delete {existing_book.bookName}? (yes/no): ").lower()
        if confirm_delete == "yes":
            db.delete_book(existing_book)
            print(f"{existing_book.bookName} was deleted.\n")
        else:
            print("Deletion canceled.")
    else:
        print("Book not found.")

# Calculates total pages of all books, to serve as a "pages read" statistic
def display_total_pages():
    total_pages = db.total_pages()
    print(f"Total number of pages read: {total_pages}\n")

def main():
    db.connect()
    # Displays the title and description only once
    print("BOOK MANAGER PRO")
    print("\nA python program for managing your favorite books.")

    # Displays the menu each time, until the user exits
    while True:
        print("\nMENU OPTIONS")
        print("1 – List your books")
        print("2 – Add a new book")
        print("3 – Edit a book")
        print("4 – Delete a book")
        print("5 – Display total pages read")
        print("6 - Exit")

        try:
            option = int(input("Select an option: "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue

        if option == 1:
            display_books()
        elif option == 2:
            add_book()
        elif option == 3:
            edit_book()
        elif option == 4:
            delete_book()
        elif option == 5:
            display_total_pages()
        elif option == 6:
            db.close()
            print("Bye!")
            break
        else:
            print("Not a valid option. Please try again.")

if __name__ == "__main__":
    main()
