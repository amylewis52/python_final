# Amy Lewis - db controller for Book Manager Pro.
# Provides queries for interacting with sqlite database

import sqlite3
from contextlib import closing
from objects import Book

conn = None

def connect():
    global conn
    if not conn:
        DB_FILE = "book_DB.sqlite"
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row

def close():
    if conn:
        conn.close()

def make_book(row):
    return Book(row["bookID"], row["bookName"], row["genre"], row["numOfPages"])

def get_books():
    query = '''SELECT bookID, bookName, genre, numOfPages
               FROM Books'''
    with closing(conn.cursor()) as c:
        c.execute(query)
        results = c.fetchall()

    books = []
    for row in results:
        book = make_book(row)
        books.append(book)
    return books

def get_book(id):
    query = '''SELECT bookID, bookName, genre, numOfPages
               FROM Books
               WHERE bookID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(query, (id,))
        row = c.fetchone()
        if row:
            book = make_book(row)
            return book
        else:
            return None

def add_book(book):
    sql = '''INSERT INTO Books
               (bookName, genre, numOfPages) 
             VALUES
               (?, ?, ?)'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (book.bookName, book.genre, book.numOfPages))
        conn.commit()

def update_book(book):
    sql = '''UPDATE Books
             SET bookName = ?,
                 genre = ?,
                 numOfPages = ?
             WHERE bookID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (book.bookName, book.genre, book.numOfPages, book.bookID))
        conn.commit()

def delete_book(book):
    sql = '''DELETE FROM Books WHERE bookID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (book.bookID,))
        conn.commit()

def total_pages():
    query = '''SELECT SUM(numOfPages) AS total_pages
               FROM Books'''
    with closing(conn.cursor()) as c:
        c.execute(query)
        result = c.fetchone()
        if result and result['total_pages']:
            return result['total_pages']
        else:
            return 0

def main():
    connect()
    books = get_books()
    for book in books:
        print(book.bookID, book.bookName, book.genre, book.numOfPages)

    total = total_pages()
    print(f"Total number of pages: {total}")

if __name__ == "__main__":
    conn = None
    main()
    close()
